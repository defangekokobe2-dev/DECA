import React from "react";

export default function App() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-gray-50 text-gray-900">
      <header className="max-w-6xl mx-auto px-6 py-6 flex justify-between items-center">
        <h1 className="text-xl font-bold">SimpleSite</h1>
        <a className="bg-indigo-600 text-white px-4 py-2 rounded-lg" href="#">Get Started</a>
      </header>

      <main className="max-w-4xl mx-auto p-6">
        <h2 className="text-4xl font-bold mb-4">Your website is ready 🚀</h2>
        <p className="text-gray-600">
          This is a ready-to-deploy React + Tailwind website. Edit <code>App.jsx</code> to customize your content.
        </p>
      </main>
    </div>
  );
}
